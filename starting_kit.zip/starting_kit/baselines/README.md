Each folder contains a baseline complexity.
These can be used to learn how to do certain things with the competition software interface.
